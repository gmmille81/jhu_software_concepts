# jhu_software_concepts -> module 1

Greg Miller
Modern Software Concepts in Python - Assignment 1 (Flask site)

This project will create a sample website with some info about me. It uses a basic flask instance to host the site (with 3 pages) on 0.0.0.0. 

Here are the steps to run it:

1. In terminal window, navigate to the folder for module_1
2. Ensure the path for module_1 is within path of python install
3. Execute "python run.py" or "python3 -m run.py", depending on system
4. Open web browser and navigate to 127.0.0.1:8080